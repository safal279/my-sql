#string function

Select length ('aashish');
select Upper('Aashish');
select lower('Aashish');

select first_name, length(first_name), upper(first_name), lower(first_name)from employee_salary
;

Select trim('    aashish.     ');




