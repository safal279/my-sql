This repository consists of MySql programs from basic understandings to the advanced level using a database. 
