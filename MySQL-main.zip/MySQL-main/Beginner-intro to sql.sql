SELECT * FROM Parks_and_Recreation.employee_demographics;

Select department_name From Parks_and_Recreation.parks_departments;
SELECT employee_id, first_name, occupation From Parks_and_Recreation.employee_salary;

SELECT* FROM Parks_and_Recreation.parks_departments,employee_salary;

SELECT * FROM Parks_and_Recreation.parks_departments,employee_demographics;

SELECT distinct gender FROM Parks_and_Recreation.employee_demographics;